package com.teddybear;

import net.fabricmc.api.ModInitializer;

public class TeddyBearMod implements ModInitializer {
    @Override
    public void onInitialize() {
        System.out.println("Teddy Bear Mod Loaded!");
    }
}
